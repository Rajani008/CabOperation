const accountSid = '{{ YOUR_ACCOUNT_SID }}';
const authToken = '{{ YOUR_AUTH_TOKEN }}';
const LookupsClient = require('twilio').LookupsClient;
const client = new LookupsClient(accountSid, authToken);

client.phoneNumbers('+15108675309').get((error, number) => {
  console.log(number.national_format);
  console.log(number.country_code);

  // This will sometimes be null
  console.log(number.caller_name);
});
