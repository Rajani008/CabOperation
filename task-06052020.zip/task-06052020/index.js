var mysql = require('mysql');
var express = require('express');
var exphbs  = require('express-handlebars');

  
 
var app = express();
 
app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');
var bodyParser = require('body-parser');
var path = require('path');
'use strict';
const fs = require('fs');

const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'cabdetails_db'
  });

  app.use(bodyParser.json())

 


app.get('/vehicleDetails',(req, res) => {
    let sql = "SELECT * FROM tbl_vehicle where is_deleted='0'";
    let query = conn.query(sql, (err, results, fields) => {
   if(err) {
    console.log(err.stack);
   }
   
    res.send(JSON.stringify({"status":200,"error":null,"response":results}));
    res.send(results);
  

  });
});


app.get('/userDetails',(req, res) => {
    let sql = "SELECT * FROM tbl_user where is_deleted='0'";
    let query = conn.query(sql, (err, results, fields) => {
   if(err) {
    console.log(err.stack);
   }
   
    res.send(JSON.stringify({"status":200,"error":null,"response":results}));
    res.send(results);
  

  });
});

app.get('/getRide/:userId',(req, res) => {

    var uid = req.params.userId;
   // console.log('user id',uid);

   conn.query('SELECT * FROM tbl_cab_rides WHERE  user_id = ?', uid, (error, results) => {
    if (error){
        console.log(error.stack);


    } 
 
    res.send(JSON.stringify({"status":200,"error":null,"response":results}));
    res.send(results);
  
});

});

let rawdata = fs.readFileSync('data.json');
let newdata = JSON.parse(rawdata);


app.get('/bookRide/:userId/:vehicleId',(req, res) => {

    var uid = req.params.userId;
    var vid = req.params.vehicleId;
//console.log("vehicle_id",vid);
    var jsondata = req.body;
   var values = [];

   for(var i=0; i< newdata.length; i++)
  values.push([newdata[i].ride_date,newdata[i].ride_location,newdata[i].ride_drop_location,vid,uid,newdata[i].ride_pickuptime,newdata[i].ride_charges,newdata[i].ride_booking_status]);


   var sql = "INSERT INTO tbl_cab_rides (ride_date,ride_location,ride_drop_location,vehicle_id,user_id,ride_pickuptime,ride_charges,ride_booking_status) VALUES ('"+newdata.ride_date+"','"+newdata.ride_location+"','"+newdata.ride_drop_location+"','"+vid+"','"+uid+"','"+newdata.ride_pickuptime+"','"+newdata.ride_charges+"','Booking Confirmed')";
  // console.log(query.sql);
  
   conn.query(sql, function (err, results) {
     if (err) {
       console.log(err.stack);
     }
    // res.send(JSON.stringify({"status":200,"error":null,"response":results}));
     res.send(results);
     console.log("Insertion done Successfully");
   
   });


 
 
   
});





    app.listen(3804);